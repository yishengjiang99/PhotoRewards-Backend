<?php
$url="http://".$_GET["url"];
?>
<html>
<body>
<iframe src=<?php echo $url ?>></iframe>
</body>
</html>
