<?php
$clientid="142437347600-j4i8t39oo9aiebmtd2f3cc75a02q2btc.apps.googleusercontent.com";
$apikey="AIzaSyBYaGwsBF_TW62QWaKcKMY49IcSwOYJHEw";
$authsite="https://accounts.google.com/o/oauth2/auth";
$redirect_uri="http://www.json999.com/postback.php";
$url=$authsite."?client_id=$clientid&redirect_uri=$redirect_uri&response_type=code&access_type=offline&scope=https://www.googleapis.com/auth/yt-analytics.readonly";
header("location: $url");
exit;
