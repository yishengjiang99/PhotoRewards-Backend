<?php
$url="https://gdata.youtube.com/feeds/api/channelstandardfeeds/most_viewed?v=2&alt=json";
 $json=file_get_contents($url);
 $aa=json_decode($json,1);
 $aa=$aa['feed']['entry'];
 foreach($aa as $a){
  insert_channel($a);  
 }


function insert_channel($a){
  var_dump($a);exit;
  echo "<br>".json_encode($a);
echo "<br>";
}
