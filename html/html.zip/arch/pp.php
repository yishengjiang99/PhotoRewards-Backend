<?php


$clientid="142437347600-j4i8t39oo9aiebmtd2f3cc75a02q2btc.apps.googleusercontent.com";
$client_secret="2iJiZElsgiYkFvCMoegmuPEQ";
$redirect_uri="http://ec2-107-22-101-168.compute-1.amazonaws.com/postback.php";
if(isset($_GET['code'])){
 $token=$_GET['code'];
}
$refresh="https://accounts.google.com/o/oauth2/token";
$fields=array("code"=>$token, "client_id"=>$clientid,"client_secret"=>$client_secret,"redirect_uri"=>$redirect_uri, "grant_type"=>"authorization_code");
foreach($fields as $key=>$value) { $fields_string .= $key.'='.$value.'&'; }
$fields_string=substr_replace($fields_string, '',-1);
$ch=curl_init();
curl_setopt($ch, CURLOPT_URL,$refresh);
curl_setopt($ch, CURLOPT_POST,count($fields));
curl_setopt($ch, CURLOPT_POSTFIELDS,$fields_string);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
$ret=curl_exec($ch);
$grants=json_decode($ret,1);
//var_dump($grants);
$access_token=$grants['access_token'];
$_SESSION['youtube_token']=$access_token;


$user="https://gdata.youtube.com/feeds/api/users/default?access_token=$access_token&alt=json";
$user=file_get_contents($user);
$user=json_decode($user,1);
$author=$user['entry']['author'][0]['name']['$t'];
var_dump($user);
$end=date("Y-m-d",time()-5*24*3600);
$start=date("Y-m-d",time()-10*24*60*60);

$analytics="https://www.googleapis.com/youtube/analytics/v1/reports?access_token=$access_token&end-date=$end&start-date=$start&metrics=views&ids=contentOwner==$author";
echo "<br>";
echo $analytics;
echo "<br>";
echo "<pre>";
$anl= file_get_contents($analytics);
$anl=json_decode($anl,1);
var_dump($anl);

//echo $analytics;
	
