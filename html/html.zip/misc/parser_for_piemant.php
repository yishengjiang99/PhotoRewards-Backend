<?php
$xml = simplexml_load_file('http://api.tradedoubler.com/1.0/vouchers?token=6D71B80D1A48154E2E96BC797C5DBB78FE0B0E3A');
var_dump($xml);















