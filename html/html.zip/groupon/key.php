<?
$key="d75793d0f51df3e074dcd1e842703e9630e91a49";
$cj="http://www.anrdoezrs.net/click-";
$cjpid="6500692";
$grouponAID="10804307";
