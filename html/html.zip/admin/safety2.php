<?php
require_once("/var/www/lib/functions.php");
if(isset($_POST)){
 foreach($_POST as $id=>$reviewed){
if($id=='allids') continue;
   $status = $reviewed=="on" ? 1 :3;
   $sql="update UploadPictures set reviewed=$status where id='$id'";
   db::exec($sql);
 }
}
$pics = db::rows("select id from UploadPictures where reviewed=0 order by RAND() limit 20");
?>
<html>
<body>
<form method=POST>
<input type=hidden name='allids' value='<? echo json_encode($pics) ?>'>
<?php foreach($pics as $i=>$pic){
 $picid=$pic['id']; 
 $url="http://json999.com/pr/uploads/".$pic['id'].".jpeg";
echo "<input name=$picid type=checkbox CHECKED /><img width=100 src=$url>";
if($i % 10 ==9) echo "<br>";
}?>
<br><br><input type=submit>
</form>
