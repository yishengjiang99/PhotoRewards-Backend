<?php
require_once("/var/www/lib/functions.php");
$rev=db::rows("select sum(revenue)/100 as rev from sponsored_app_installs where created>date_sub(now(), interval 1 day)");
$ppl24 =db::rows("select sum(amount)/100 as payout_out from PaypalTransactions where created>date_sub(now(), interval 1 day)");
$giftcards24=db::rows("select sum(r.Points)/1000 as cards_out from reward_codes a join rewards r on a.reward_id=r.id where given_out=1 and date_redeemed>date_sub(now(), interval 1 day)");

$revall=db::rows("select sum(revenue)/100 as rev from sponsored_app_installs");
$giftcardsall=db::rows("select sum(r.Points)/1000 as cards_out from reward_codes a join rewards r on a.reward_id=r.id where given_out=1");

$revenue_breakout=db::rows("select sum(revenue)/100 as revenue, network from sponsored_app_installs where created>date_sub(now(), interval 1 day) group by network");
$revenue_breakout_all=db::rows("select sum(revenue)/100 as rev, network from sponsored_app_installs group by network");
$ppoutall=db::rows("select sum(amount)/100 as pplout from PaypalTransactions");
$newusers_today=db::rows("select avg(stars),sum(stars), avg(xp), count(1) as cnt, app from appuser where created>date_sub(now(), interval 1 day) group by app");
$reffday=db::rows("select sum(ltv)/100 as revenue,sum(points_to_agent)*2/1000 as cost,count(1) as joiners,count(distinct agentUid) as agent from appuser a join referral_bonuses b 
 on a.id=b.joinerUid where a.created>date_sub(now(), interval 1 day)");

$refweek=db::rows("select sum(ltv)/100 as revenue,sum(points_to_agent)*2/1000 as cost,count(1) as joiners,count(distinct agentUid) as agent from appuser a join referral_bonuses b 
 on a.id=b.joinerUid where a.created>date_sub(now(), interval 7 day)");

$allusers=db::rows("select app, avg(stars),sum(if(modified>date_sub(now(), interval 1 day),1,0)) as active_today, avg(xp),count(1) as cnt,sum(stars)/1000 as account_payable, app from appuser group by app having count(1)>5");
$cashouts=db::rows("select b.name, b.Points,sum(given_out),count(1) from reward_codes a join rewards b on a.reward_id=b.id group by a.reward_id");
$referrals=db::rows("select count(1), sum(points_to_agent)/1000 as paid_to_agent,sum(points_to_agent)/1000 as paid_to_agent,sum(points_to_joiner)/1000 as paid_to_joiner, count(distinct agentUid) as agents from referral_bonuses");
$ppal=db::rows("select sum(amount),count(1),count(distinct transfer_to_user_id) as unique_users from PaypalTransactions");
$rolling7user=db::rows("select date_format(created,'%Y-%m-%d') as date, count(1) as new, sum(if(modified>date_sub(now(), interval 1 day), 1, 0)) as activetoday,avg(ltv) as ltv ,sum(if(ltv>0,1,0)) as has_earned, sum(if(modified>date_sub(now(), interval 1 day), 1, 0))/count(1) as attribution, avg(stars)/10 as balance from appuser where app='picrewards' and created>date_sub(now(), interval 14 day) and banned=0 group by datediff(now(),created) order by created desc");
echo "<table><tr><td>";
echo "<table border=1>";
echo "<tr><td colspan=3>P&L last 24</td></tr>";
echo "<tr><td>".rows2table($rev)."</td>";
echo "<td>".rows2table($ppl24)."</td>";
echo "<td>".rows2table($giftcards24)."</td></tr></table>";
echo "</td><td>";
echo "<table border=1>";
echo "<tr><td colspan=3>P&L All Time</td></tr>";
echo "<tr><td>".rows2table($revall)."</td>";
echo "<td>".rows2table($giftcardsall)."</td>";
echo "<td>".rows2table($ppoutall)."</td></tr></table>";
echo "</td></tr></table>";

echo "<table border=1>";
echo "<tr><td>Referrals-24</td><td>referrals week</td></tr>";
echo "<tr><td>".rows2table($reffday)."</td>";
echo "<td>".rows2table($refweek)."</td>";
echo "</tr></table>";


echo "r7";
echo rows2table($rolling7user);

echo "all users";
echo rows2table($allusers);

echo "<table border=1>";
echo "<tr><td colspan=2>Network Performances</td></tr>";
echo "<tr><td>Today</td><td>Alltime</td></tr>";
echo "<tr><td valign=top>".rows2table($revenue_breakout)."</td>";
echo "<td valign=top>".rows2table($revenue_breakout_all)."</td></tr></table>";
echo "</table>";
echo "Inventory";
echo rows2table($cashouts);
echo "referrals";
echo rows2table($referrals);

?>
