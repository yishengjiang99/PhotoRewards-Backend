<?
require_once("/var/www/lib/functions.php");
require_once("/var/www/html/pr/apns.php");
apnsUser(2902,"Rate us 5 stars!","fff","http://www.google.com");
