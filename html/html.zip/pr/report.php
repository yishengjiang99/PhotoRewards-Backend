
<?
error_log(json_encode($_POST));
die(json_encode(array("title"=>"Thanks","msg"=>"Please click on the picture to complete your report.")));
