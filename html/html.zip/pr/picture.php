<?php
$id=$_GET['id'];
$uid=intval($_GET['uid']);
if(intval($id)!=0 && $_GET['r']=='r'){
 require_once("/var/www/lib/functions.php");
 $uid=$id;
 $mid=$_GET['mid'];
 $t=$_GET['t'];
 $h=$_GET['h'];
 $cb=$_GET['cb'];
 if($h!=md5($uid.$mid."watup".$t)) die("rong");
 $select ="select aes_decrypt(code,'supersimple') as Reward, concat('',b.name) as Item from reward_codes a join rewards b on a.reward_id=b.id where a.rewarded_to_uid=$uid";
 $rewards=db::rows($select);
}else{
$url="http://www.json999.com/pr/uploads/$id.jpeg";
 header("location: http:/www.json999.com/pr/p.php?uid=$uid&imgurl=$url");
 exit;
}
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" dir="ltr">
<head>
<style type="text/css">
a, a:visited { color:#0645AD;font-size:151% }
BLOCKQUOTE { margin-right:3px;margin-left:15px; }
ul { margin-left:0px; padding-left:0px; list-style-type:none; }
</style>
</head>
<body>

<div id="punwrap">
<h2>Redemption History <a href='<?php echo $cb?>://'>Back To the App</h2>
<br><br><br>
<div id="idx1" class="blocktable" style="width:100%;">
	<div class="box" style="width:100%;">
		<div class="inbox">
			<table cellspacing="2" width=100% border=0>
			<tbody>
			<?php foreach ($rewards as $r){?>
 				<tr>
					<td class="tcl">
						<div class="intd">
							<div class="icon"><div class="nosize"></div></div>
							<div class="tclcon">
								<h3 style="margin:0;padding:0;">
		<a href="<?php echo $r['url']; ?>" style="border: 1px solid #999; border-top-right-radius: 7px; border-bottom-left-radius:7px;border-bottom-right-radius: 7px; border-top-left-radius:7px;background-color:#CCC;text-decoration:none;color:#000;display:inherit;width:100%;padding-top:6px;padding-bottom:6px;background-image:url('/images/open.png');background-position:right;background-repeat:no-repeat;">
		<div style="padding-left:2px;padding-right:20px;"><img src=http://cdn.boardhost.com/invisible.gif width=3 border=0><?php echo $r['Item'].": ".$r['Reward']; ?></div></a></h3>
							</div>
						</div>
					</td>
				</tr>
			<? }?>
			</tbody>
			</table>
		</div>
	</div>
</div><br>

<div id="brdfooter" class="block">
	<h2><span></span></h2>
	<div class="box">
		<div class="inbox">
			<div class="clearer"></div>
		</div>
	</div>
</div>

</div>
</div>

</html>


