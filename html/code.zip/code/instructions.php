<?php
$instruct=array("Step 1: Tap on title on the list",
"Step 2: Upload a picture to earn Points",
"Step 3: Redeem points for Gift Cards",
"Share Pictures for XP (to level up)",
"Level Up = bigger points for your Bonus Code",
"Be sure to read and follow the rules!");
die(json_encode($instruct));
