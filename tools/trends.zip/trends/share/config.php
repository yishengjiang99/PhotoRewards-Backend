<?php
define('DB_ADDR', 'localhost');
define('DB_USER', 'root');
define('DB_PSWD', '');
define('DB_NAME', 'trends');

define('DATE_FORMAT', 'Y-m-d, H:i:s');
?>
