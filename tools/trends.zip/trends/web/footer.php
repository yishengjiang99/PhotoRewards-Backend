<p class="footer">Google Hot Trends Atom scraper by
<a href="http://www.fromzerotoseo.com">From Zero To SEO</a></p>
</body>
</html>
