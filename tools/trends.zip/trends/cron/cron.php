<?php
include('../share/config.php');
include('../share/Messenger.php');
include('../share/MySqlUtil.php');
include('../share/scraper.php');

Messenger::log('Scraper started');

$mySqlUtil = new MySqlUtil();

$trends = scrapGoogleHotTrendsAtom();
if (empty($trends)) {
    Messenger::error('Could not scrap trends');
    exit;
}

$mySqlUtil->saveTrends($trends);

Messenger::log('Trends saved');
?>
